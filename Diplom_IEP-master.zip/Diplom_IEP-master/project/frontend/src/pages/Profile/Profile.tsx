import { Layout } from 'antd';
import { HeaderCustom } from '../../components/Header';
import React from 'react';

export const Profile = (): JSX.Element => {
    return (
        <Layout>
            <HeaderCustom />
        </Layout>
    );
};
